const user = require('../models/UserModel');
const joi = require('joi');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Op } = require("sequelize");
const { sendEmail,send_notification,get_admin,get_user } = require('../helper');
const user_profile = require('../models/User_profileModel');
const fs = require('fs');
const clinic = require('../models/ClinicModel');
const media = require('../models/MediaModel');
const advertisment = require('../models/Advertisment_bannerModel');
const booking = require('../models/BookingModel');
const path = require('path')
const ejs = require('ejs');
const sequelize = require('sequelize');
const calender = require('../models/Calender_dateModel');
const user_anwser = require('../models/UserAnswerModel');
const question = require('../models/QuestionsModel');
const answer = require('../models/AnswerModel');
const re_schedule_patient = require('../models/Re_schedule_patientModel');
const re_schedule = require('../models/Re_scheduleModel');
const feedback = require('../models/feedbackModel');
const medicine = require('../models/MedicineModel');
const notification = require('../models/NotificationModel');
const category = require('../models/CategoryModel');
const schedule = require('../models/SchdeuleModel');

//Auth
exports.login = async (req, res, next) => {

    const schema = joi.object({
        email: joi.string().required().email(),
        password: joi.string().required(),
        fcm_token: joi.required(),
        type: joi.string().required().valid('patient','doctor')
    });

    try {

        await schema.validateAsync(req.body);
        
        const check = await user.findOne({
            where: { email: req.body.email, type: req.body.type },
            include:[{
                model : user_anwser,
                limit:1
            },{
                model: user_profile
            }]
        });

        if (!check) throw new Error('Email not found');

        const passcheck = bcrypt.compareSync(req.body.password, check.password);

        if (!passcheck) throw new Error('password not matched');

        if (check.is_activated == '0')
        {
             let data = await ejs.renderFile(path.join(__dirname, "../views/verify.ejs"),{
                link: 'https://afrad.arabboard.org/api/verify/email/' + check.id
            });
            
            await sendEmail(req.body.email, 'verify email', data);
            throw new Error('Please verify the email');
        }
    
        if (check.is_login == '1') throw new Error('You were login with another device. Please logout from all other devices');

        if (check.is_block == '1') throw new Error('You were blocked by admin');

        const token = jwt.sign(
            { email: check.email, userId: check.id, type: check.type },
            process.env.AUTH_KEY
        );

        // let fcm = req.body.fcm_token.replace(/^"(.*)"$/, '$1');
        let fcm = req.body.fcm_token;
        
        check.token = token;
        check.fcm_token = fcm;
        check.is_login = '1';
        check.save();

        
        const user_ans = await user_anwser.findAll({
            where:{ user_id :check.id }
        });
        
        let arr =[];
        user_ans.forEach(element=>{
            arr.push(element.question_id)
        })
    
        const ques = await question.findAll({
            where :{ gender:check.user_profile.gender,question_id : null }
        });
        
        let comp_ques = true;
        for (let element of ques) {
            
            if(!arr.includes(element.id))
            {
                comp_ques = false;
                break;
            }            
        };

        

        return res.status(200).json({
            data: check,
            complete_ques:comp_ques,
            status: true,
            message: "login successfully"
        });

    } catch (err) {
        console.log(err);
        err.status = 404;
        next(err);
    }

}

exports.admin_login = async (req, res, next) => {

    const schema = joi.object({
        email: joi.string().required().email(),
        password: joi.string().required(),
        fcm_token: joi.string().required()
    });

    try {

        await schema.validateAsync(req.body);

        const check = await user.findOne({
            where: { email: req.body.email , type:'admin' }
        });

        if (!check) throw new Error('Email not found');

        const passcheck = bcrypt.compareSync(req.body.password, check.password);

        if (!passcheck) throw new Error('password not matched');

        const token = jwt.sign(
            { email: check.email, userId: check.id, type : check.type },
            process.env.AUTH_KEY
        );

        check.token = token;
        check.fcm_token = req.body.fcm_token;
        check.save();

        return res.status(200).json({
            data: check,
            status: true,
            message: "Admin login successfully"
        });

    } catch (err) {
        err.status = 404;
        next(err);
    }

}

exports.register = async (req, res, next) => {

    const schema = joi.object({
        first_name: joi.string().required(),
        last_name: joi.string().required(),
        email: joi.string().required().email(),
        password: joi.string().allow(''),
        phone: joi.number().required(),
        gender: joi.string().required().valid('Male', 'Female', 'other'),
        type: joi.string().required().valid('patient','doctor')
    });

    try {
        await schema.validateAsync(req.body);

        const check = await user.findOne({ 
            where: { 
                email: req.body.email,
                [Op.or]: [
                  { type: 'admin' },
                  { type: req.body.type }
                ]
            }
        });

        if (check) throw new Error('Email already exists');

        const u_id = await user.create({
            first_name: req.body.first_name,
            last_name: req.body.last_name,
            email: req.body.email,
            phone: req.body.phone,
            password: await bcrypt.hash(req.body.password, 12),
            type: req.body.type
        });

        await user_profile.create({
                user_id : u_id.id,
                gender : req.body.gender
        });

        let data = await ejs.renderFile(path.join(__dirname, "../views/verify.ejs"),{
            link: 'https://afrad.arabboard.org/api/verify/email/' + u_id.id
        });
        
        
        if(req.body.type == 'doctor')
        {
            const alpha = Math.random().toString(36).substr(2, 6) ;
            
            u_id.password = await bcrypt.hash(alpha, 12);
            await u_id.save();

            data = await ejs.renderFile(path.join(__dirname, "../views/doctor_register.ejs"), {
                email: req.body.email,
                pass: alpha,
                link:'https://afrad.arabboard.org/api/verify/email/'+u_id.id
            });

        }

        if(req.body.type == 'patient')
        {
            let dd = await get_admin();
            let msg = req.body.first_name + ' '+ req.body.last_name+ ' has register as patient'
            await send_notification(dd.fcm_token,'New Registration',msg,dd.id,'patient_register',u_id.id,req.body.type)
        }

        await sendEmail(req.body.email, 'verify email', data);

        return res.status(200).json({
            data: [],
            status: true,
            message: "Register successfully"
        });


    } catch (err) {
        err.status = 404;
        next(err);
    }

}

exports.detail = async (req, res, next) => {

    const data = await user.findOne({
        where: { id: req.params.id },
        include:[{
            model:user_profile
        },
        {
            model : re_schedule_patient,
            as : "patient_data",
            include:[{
                model :booking
            },{
                model :calender
            }]
        },
        {
            model : re_schedule,
            include:[{
                model :booking
            },{
                model  :calender
            }]
        },
        {
            model :booking,
            as : "patient",
            include:[{
                model :calender
            },{
                model : medicine
            },{
                model :feedback
            }]
        },
        {
            model :booking,
            as : "doctor",
            include:[{
                model :calender
            },{
                model : medicine
            },{
                model :feedback
            }]
        }
        ]
    });

    return res.status(200).json({
        data: data,
        status: true,
        message: "Detail"
    });

}

exports.detail_by_token = async (req, res, next) => {

    try{
        const data = await user.findOne({
            where: { id: req.user_id },
            include: [{
                model: user_profile
            },{
                model : user_anwser,
                include:[{
                    model : question
                }]
            }]
        });


        const user_ans = await user_anwser.findAll({
            where:{ user_id :req.user_id }
        });
        
        let arr =[];
        user_ans.forEach(element=>{
            arr.push(element.question_id)
        })
    
    
        const ques = await question.findAll({
            where :{ gender:data.user_profile.gender,question_id : null }
        });
        
        let comp_ques = true;
        for (let element of ques) {
            
            if(!arr.includes(element.id))
            {
                comp_ques = false;
                break;
            }            
        };

        return res.status(200).json({
            data: data,
            complete_ques:comp_ques,
            status: true,
            message: "User Detail"
        });

    }
    catch(err)
    {
        err.status=400;
        next(err);
    }

}

exports.forget_password = async (req, res, next) => {

    const schema = joi.object({
        email: joi.string().required().email(),
        type: joi.string().required().valid('patient','doctor')
    })

    try {

        await schema.validateAsync(req.body);

        const emailcheck = await user.findOne({
            where: { email: req.body.email,type:req.body.type }
        });

        if (!emailcheck) throw new Error('Email not found');

        const otp = Math.floor(Math.random() * (9999 - 999) + 999);

        let data = await ejs.renderFile(path.join(__dirname, "../views/forget.ejs"), {
            otp: otp
        });


        await sendEmail(emailcheck.email, 'Forget password OTP', data);
        
        return res.status(200).json({
            data: otp,
            status: true,
            message: "Otp for the user"
        });

    } catch (err) {
        err.status = 404;
        next(err);
    }

}

exports.change_password = async (req, res, next) => {

    const schema = joi.object({
        email: joi.string().required().email(),
        password: joi.string().required(),
        type: joi.string().required().valid('patient','doctor','admin')
    });

    try {
        await schema.validateAsync(req.body);

        const emailcheck = await user.findOne({
            where: { email: req.body.email,type:req.body.type }
        });

        if (!emailcheck) throw new Error('Email not found');

        emailcheck.password = await bcrypt.hash(req.body.password, 12)
        emailcheck.save();

        return res.status(200).json({
            data: [],
            status: true,
            message: "Password change successfully"
        });

    } catch (err) {
        err.status = 404;
        next(err);
    }

}

exports.logout = async (req, res, next) => {

    await user.update({ token: null, is_login : '0'}, {
        where: {
            id: req.user_id
        }
    });

    return res.status(200).json({
        data: [],
        status: true,
        message: "Logout successfully"
    });

}

exports.logout_by_id = async (req, res, next) => {


    try{

        const data = await user.findOne({
            where: {id: req.params.id}
        })

        // await user.update({ token: null, is_login : '0'}, {
        //     where: {
        //         id: req.params.id
        //     }
        // });
        
        
        data.token = null;
        data.is_login ='0';
        await data.save();
        
        
        await send_notification(data.fcm_token,'Logout','Admin logout you',data.id,'logout',data.id,data.type)
        
    
        return res.status(200).json({
            data: [],
            status: true,
            message: "Logout successfully"
        });
        
    }catch(err){
        err.status = 400;
        next(err);
    }

}

//Notifications
exports.all_notification = async(req,res,next)=>{
    
    const schema = joi.object({
        id: joi.string().required(),
        page : joi.string().required()
    });
    
    try{
        
        await schema.validateAsync(req.params);
        
        await notification.update({
            status : 'read'
        },{
            where :{ user_id : req.params.id }
        })
        
        let limit = 10;
        let offset = 0 + (req.params.page - 1) * limit
        
        const data = await notification.findAll({
            where :{ user_id : req.params.id },
            order:[ ['id','DESC'] ],
            limit : limit,
            offset: offset
        });
        
         return res.status(200).json({
            data: data,
            status: true,
            message: "All notification"
        });
        
        
    }catch(err){
        err.status = 400;
        next(err);
    }
    
}

exports.delete_notification = async(req,res,next)=>{
    
    const schema = joi.object({
        user_id: joi.number().required(),
        noti_id : joi.string().required()
    });
    
    try{
        await schema.validateAsync(req.body);
        
        if(req.body.noti_id == 'all')
        {
            await notification.destroy({
                where :{ user_id : req.body.user_id }
            })
          
            
        }
        else
        {
            await notification.destroy({
                where :{ id : req.body.noti_id }
            })
            
        }
        
        return res.status(200).json({
            data: [],
            status: true,
            message: "Notification delete successfully"
        });
        
    }catch(err)
    {
        err.status=500;
        next(err);
    }
}

exports.get_five_notification = async(req,res,next)=>{
    
     const schema = joi.object({
        id: joi.string().required()
    });
    
    try{
        
        await schema.validateAsync(req.params);
        
        const data = await notification.findAll({
            where :{ user_id : req.params.id,status :'un_read' },
            order:[ ['id','DESC'] ],
            limit : 5
        });
        
        const count_data = await notification.count({
            where :{ user_id : req.params.id,status :'un_read' }
        })
        
         return res.status(200).json({
            data: data,
            total : count_data,
            status: true,
            message: "5 notification"
        });
        
        
    }catch(err){
        err.status = 400;
        next(err);
    }
    
}

exports.send_notification = async(req,res,next)=>{
    
    const schema = joi.object({
        title : joi.string().required(),
        message : joi.string().required(),
        type : joi.string().required().valid('patient','doctor','all')
    });
    
    try{
        await schema.validateAsync(req.body);
        
        let where = {
           type : req.body.type
        }
        
        if( req.body.type == 'all' ){  where = { type : { [Op.ne]: 'admin' } } }
       
        
        const data = await user.findAll({
            where,
        });
        
        
        data.forEach( async(element)=>{
            if(element.fcm_token)
            {
                await send_notification(element.fcm_token,req.body.title,req.body.message,element.id,'send_notification',0,element.type)    
            }
        })
        
        return res.status(200).json({
            data: [],
            status: true,
            message: "notification send successfully"
        });
        
        
        
    }catch(err){
        err.status = 400;
        next(err);
    }
    
}

exports.send_single_notification = async(req,res,next)=>{
    
    const schema = joi.object({
        title : joi.string().required(),
        message : joi.string().required(),
        user_id : joi.array().required(),
        type : joi.string().required().valid('patient','doctor')
    });
    
    try{
        await schema.validateAsync(req.body);
        
        const data = await user.findAll({
            where:{ 
                type:req.body.type,
                id : req.body.user_id
            }
        });
        
        
        data.forEach( async(element)=>{
            if(element.fcm_token)
            {
                await send_notification(element.fcm_token,req.body.title,req.body.message,element.id,'send_notification',0,element.type)    
            }
        })
        
        return res.status(200).json({
            data: [],
            status: true,
            message: "notification send successfully"
        });
        
        
        
    }catch(err){
        err.status = 400;
        next(err);
    }
    
}


exports.all_list = async (req, res, next) => {

    const schema = joi.object({
        type: joi.string().required().valid('patient', 'doctor')
    });

    try {

        await schema.validateAsync(req.body);

        const data = await user.findAll({ 
            where: { type: req.body.type },
            order:[
                ['id','DESC']
            ],
            include:[{
                model : user_profile
            }]
            
        });

        return res.status(200).json({
            data: data,
            status: true,
            message: "List"
        });

    } catch (err) {
        err.status = 400;
        next(err);
    }

}

exports.all_users = async (req, res, next) => {

    try {

        const data = await user.findAll({
            where:{ type:{ [Op.ne]:'admin' } },
            group:['email'],
            order:[['id','Desc']]
        });
        
        
        let dts = [];
        for( let val of data ){
            
            let check = await user.count({
                where:{ email: val.email }
            });
            
            let dta = {};
            dta.id = val.id;
            dta.first_name = val.first_name;
            dta.last_name = val.last_name;
            dta.email = val.email;
            dta.image = val.image;
            
            if(check> 1)
            {
                dta.type = 'both'; 
            }
            else
            {
                dta.type = val.type;
            }
            
            
            dts.push(dta);
            
        }
        
        

        return res.status(200).json({
            data: dts,
            status: true,
            message: "All users list"
        });

    } catch (err) {
        err.status = 400;
        next(err);
    }

}

exports.detail_by_email = async(req,res,next)=>{
    
    const schema = joi.object({
        email: joi.string().required()
    });
    
    try{
        
        await schema.validateAsync(req.body);
        
        let doctor = await user.findOne({
            where:{ email : req.body.email, type:'doctor'  }
        })
        
        let patient = await user.findOne({
            where:{ email : req.body.email, type:'patient'  }
        })
        
        let data = {}
        data.doctor = doctor;
        data.patient = patient;
        
        return res.status(200).json({
            data: data,
            status: true,
            message: "User detail by email"
        });
        
        
    }catch(err)
    {
        err.status = 400;
        next(err);
    }
    
}

exports.block_user = async (req, res, next) => {

    const schema = joi.object({
        user_id : joi.number().required(),
        block : joi.string().required().valid('1','0')
    })

    try {

        await schema.validateAsync(req.body);

        const data = await user.findOne({ where : { id : req.body.user_id } });

        if(!data) throw new Error('User not found');

        data.is_block = req.body.block;
        await data.save();
        
        if(req.body.block == '1')
        {
            await send_notification(data.fcm_token,'Blocked','Admin blocked you',data.id,'block',req.body.user_id,data.type)
        }
        else{
            await send_notification(data.fcm_token,'Un-blocked','Admin unblocked you',data.id,'unblock',req.body.user_id,data.type)
        }

        return res.status(200).json({
            data: data,
            status: true,
            message: "successfull"
        });
        
    } catch (err) {
        err.status = 400;
        next(err);
    }

}

exports.edit_profile = async(req,res,next)=>{

    const schema = joi.object({
        age: joi.string().allow(null),
        address: joi.string().allow(null),
        first_name: joi.string().required(),
        last_name: joi.string().required(),
        specility : joi.string().allow(null),
        experience : joi.string().allow(null),
        email : joi.string().allow(null),
        phone : joi.string().allow(null),
        qualification: joi.string().allow(null),
        about: joi.string().allow(null),
        gender : joi.string().required().valid('Male','Female','other'),
        user_id : joi.string().required()
    });

    try {
        
        await schema.validateAsync(req.body);

        const check = await user.findOne({
            where : { id : req.body.user_id }
        });

        if(!check) throw new Error('user not found');

        if(req.body.email)
        {
            const check_email = await user.findOne({ where :{ email : req.body.email } })
            
            if(check_email) throw new Error('Email already exists');
            check.email = req.body.email;
            
        }
        

        check.first_name = req.body.first_name;
        check.last_name = req.body.last_name;
        check.phone = req.body.phone;
        await check.save();

        if(req.file)
        {
            if(check.image){
              fs.unlinkSync(check.image);  
            } 
            check.image = req.file.path;
            await check.save();
        }

        await user_profile.update({
            age:req.body.age,
            address : req.body.address,
            gender : req.body.gender,
            specility : req.body.specility,
            experience : req.body.experience,
            qualification: req.body.qualification,
            about:req.body.about
        },{
            where : {user_id : req.body.user_id}
        });

        let msg = check.first_name +' '+check.last_name+ ' updated his profile';
        let dd = await get_admin();
        let type = check.id+'_'+check.type;

        await send_notification(check.fcm_token,'Profile update','Your profile has been updated',check.id,'user_profile_update',0,check.type) //user notification
        await send_notification(dd.fcm_token,'User Profile update',msg,dd.id,'admin_update_profile_msg',type,check.type) // admin notification
        
        return res.status(200).json({
            data: [],
            status: true,
            message: "User profile updated"
        });

    } catch (err) {

        if(req.file)
        {
            fs.unlinkSync(req.file.path);

        }

        err.status = 400;
        next(err);
    }

}
 
exports.verify_email = async (req, res, next) => {

    const data = await user.update({
        is_activated : '1'
    },{ where : { id :req.params.id  } })

     return res.render( path.join(__dirname, "../views/successfull.ejs") );
    
    // return res.send('Verify successfully');

}

//Dashboard
exports.dashboard = async(req,res,next)=>{
    
    try{
        
        //patient
        const new_patient = await user.findAll({
            where :{ type : "patient" },
            order:[
                ['id','DESC']
                ],
            limit : 5
        });
        const total_patient = await user.count({ where :{  type : "patient"  } });
        
        //doctor
        const new_doctor = await user.findAll({
            where :{ type : "doctor" },
            order:[
                ['id','DESC']
                ],
            limit : 5
        });
        const total_doctor = await user.count({ where :{  type : "doctor"  } });
        
        //booking
        const total_booking = await booking.count();
        const total_accepted_booking = await booking.count({ where : { status : ["accepted"] } });
        const total_cancel_booking = await booking.count({ where : { status : "cancel" } });
        const total_reject_booking = await booking.count({ where : { status : "reject" } });
        const total_pending_booking = await booking.count({ where : { status : "pending" } });
        const total_re_schedule_pending_booking = await booking.count({
            where : { status : "re_schedule_pending" },
        });
        const assign_booking = await booking.findAll({
            where : { status : ["accepted"], doctor_id: {[Op.ne]: null } },
            order:[
                ['id','DESC']
                ],
            limit : 5,
            include:[{
                model : user,
                as: "doctor",
                include :[{
                    model : user_profile
                }]
            },
            {
                model : user,
                as: "patient"
            },
            {
                model : calender
            }]
        })
        
        const data = {};
        
        data.new_patient = new_patient;
        data.new_doctor = new_doctor;
        data.assign_booking = assign_booking;
        data.total_patient = total_patient;
        data.total_doctor = total_doctor;
         
        //booking
        data.total_booking = total_booking;
        data.total_accepted_booking = total_accepted_booking;
        data.total_cancel_booking = total_cancel_booking;
        data.total_re_schedule_pending_booking = total_re_schedule_pending_booking;
        data.total_reject_booking = total_reject_booking;
        data.total_pending_booking = total_pending_booking;
        
        
        
        return res.status(200).json({
            data: data,
            status: true,
            message: "Admin dashboard"
        });
        
    }catch(err){
        err.status = 400;
        next(err);
    }
    
}

exports.patient_dashboard = async(req,res,next)=>{
 
    try{
         
        const banner = await media.findAll({
            where :{ type : "banner" }
        });
        
        const user = await get_user(req.user_id);
        
        const questions = await question.findAll({
            where:{ gender : user.user_profile.gender,question_id :null },
            order:[['id','ASC']],
            include:[{
                model:question,
                as:'sub_question',
                include:[{
                    model:answer,
                    attributes: {exclude: ['createdAt','updatedAt']}    
                }]
            },{
                model : answer,
                required:false,
                attributes: {exclude: ['createdAt','updatedAt']}
            },{
                model:category
            }]
        });
        
        
        const data = {};
        data.banner = banner;
        data.questions = questions;
        // data.user = user;
        
        return res.status(200).json({
            data: data,
            status: true,
            message: "Patient dashboard"
        });
         
    }
    catch(err)
    {
        err.status= 400;
        next(err);
    }
    
}

exports.doctor_dashboard = async(req,res,next)=>{
    
    const schema = joi.object({
        date: joi.string().required()
    });
    
    try{
        
        
        await schema.validateAsync(req.body);
         
        const banner = await media.findAll({
            where :{ type : "banner" }
        });
        
        
        const cal = await calender.findOne({
            where: { date: req.body.date }
        });
        
        let single_date = {};

        if (cal) {
            
            single_date = await schedule.findAll({
                where: { doctor_id: req.user_id, calender_id: cal.id },
                order:[ ['start_time','ASC'] ],
                include: [{
                    model: booking,
                    include: [{
                        model: user,
                        as:"patient",
                        include:[{
                            model : user_profile
                        }]
                        // include:[{
                        //     model : user_anwser,
                        //     include:[{
                        //         model : question
                        //     },
                        //     {
                        //         model : answer
                        //     }]
                        // }]
                    }]
                }]
            });
            
            // console.log(single_date)
            
        }

        const count_data = await notification.count({
            where :{ user_id : req.user_id,status :'un_read' }
        })
        
        
        const dta = await user.findOne({
            where:{ id : req.user_id },
            include:[{
                model:user_profile
            }]
        })
        
        let u_profile = false
        
        if(dta.user_profile.about)
        {
            u_profile = true;
        }
        
        
        const data = {};
        data.banner = banner;
        data.single_date = single_date;
        data.notification_count = count_data;
        data.user_profile = u_profile;
        
        return res.status(200).json({
            data: data,
            status: true,
            message: "Doctor dashboard"
        });
         
    }
    catch(err)
    {
        err.status= 400;
        next(err);
    }
    
}

exports.guest_dashboard = async(req,res,next)=>{
    
    try{
        
        const doctor = await user.findAll({
            where:{ type:'doctor' },
            include:[user_profile]
        })
        
        const banner = await media.findAll({
            where :{ type : "banner" }
        })
        
        const data = {};
        data.doctor = doctor;
        data.banner = banner;
        
        return res.status(200).json({
            data: data,
            status: true,
            message: "Guest dashboard"
        });
        
    }
    catch(err)
    {
        err.status=500;
        next(err);
    }
    
}

exports.day_chat_patient = async(req,res,next)=>{
    
    const schema = joi.object({
        month : joi.number().required(),
        year : joi.number().required(),
        total_days : joi.number().required()
    })
    
    try{
        await schema.validateAsync(req.body);
        
        
        let arr=[];
        for(let i=1; i<=req.body.total_days; i++)
        {
            
            
            let patient_charts = await user.count({
                where:{ 
                    type:"patient", 
                    created_at : sequelize.where(sequelize.fn("year", sequelize.col("created_at")), req.body.year),
                    [Op.and] : [
                        {created_at : sequelize.where(sequelize.fn("month", sequelize.col("created_at")), req.body.month)},
                        {created_at : sequelize.where(sequelize.fn("day", sequelize.col("created_at")), i)} 
                    ]
                }
            });
            
            arr.push({
                "date":i,
                "data" :patient_charts
            })
            
        }
        
     return res.status(200).json({
            data: arr,
            status: true,
            message: "Admin dashboard"
        });
        
    }catch(err)
    {
        
    }
    
}

exports.all_booking = async(req,res,next)=>{
    
    const schema = joi.object({
        status : joi.string().required().valid('all','accepted','reject','pending','cancel')
    })
    
    try{
    
        await schema.validateAsync(req.body)
        
        let where = {
           status : req.body.status
        }
        
        if( req.body.status == 'all' ){  where = ''; }
       
        const data = await booking.findAll({
            where,
            order:[['id','DESC']],
            include: [{
                    model: user,
                    as:"patient"
                },
                {
                    model: user,
                    as:"doctor"
                },
                {
                    model : calender
                }]
        });
        
        return res.status(200).json({
            data: data,
            status: true,
            message: "All booking list"
        });
        
    }catch(err){
        err.status = 400;
        next(err);
    }
    
}

//banner
exports.add_banner = async(req,res,next)=>{
    
    req.files.forEach( async(element)=>{
        
        await media.create({
            path : element.path ,
            type:"banner"
        })
        
    })
    
    
    return res.status(200).json({
            data: [],
            status: true,
            message: "Banner add successfully"
    });
    
}

exports.all_banner = async(req,res,next)=>{
    
    try{
        
        const data = await media.findAll({
            where :{ type : "banner" }
        })
        
        return res.status(200).json({
            data: data,
            status: true,
            message: "All banners"
        });
        
    }catch(err){
        err.status = 400;
        next(err);
    }
    
}

exports.delete_banner = async(req,res,next)=>{
    
    const schema = joi.object({
        id : joi.string().required()
    });
    
    try{
        await schema.validateAsync(req.params);
        
        const check = await media.count({
            where :{ type:"banner" }
        });
        
        if(check == '1') throw new Error('It is compusory to have one banner. So you cannot delete banner');
        
        const data = await media.findOne({
            where :{ id : req.params.id }
        });
        
        if(!data) throw new Error('Banner not found');
        
        fs.unlinkSync(data.path);
        
        await data.destroy();
        
        return res.status(200).json({
            data: [],
            status: true,
            message: "banner deleted successfully"
        });
        
    }catch(err){
        err.status = 400;
        next(err);
    }
    
}

//Advertisment banner
exports.add_adv_banner = async(req,res,next)=>{

    const schema = joi.object({
        title: joi.string().required(),
        desc: joi.string().required()
    });

 
    try{
        await schema.validateAsync(req.body);

        await advertisment.create({
            title : req.body.title,
            desc : req.body.desc,
            path : req.file.path
        })
        
        return res.status(200).json({
            data: [],
            status: true,
            message: "Advertisment banner added successfully"
        });
         
    }catch(err){
        
        if(req.file){
            fs.unlinkSync(req.file.path);  
        } 
            
         err.status=400;
         next(err);
    }
    
}

exports.edit_adv_banner = async(req,res,next)=>{
 
    const schema = joi.object({
        title: joi.string().required(),
        desc: joi.string().required(),
        id : joi.number().required()
    });
    
    try{
        
        await schema.validateAsync(req.body);

        const data = await advertisment.findOne({
            where :{ id : req.body.id }
        });

        data.title = req.body.title;
        data.desc = req.body.desc;
        
        if(req.file)
        {
            
            if(data.image){
              fs.unlinkSync(data.image);  
            } 
            data.path = req.file.path;
            
        }

        await data.save();
        
        return res.status(200).json({
            data: [],
            status: true,
            message: "Advertisment banner edited successfully"
        });
        
         
    }catch(err){
         err.status=400;
         next(err);
    }
    
}

exports.delete_adv_banner = async(req,res,next)=>{
 
    const schema = joi.object({
        id: joi.string().required()
    });
 
    try{
       await schema.validateAsync(req.params);

        const data = await advertisment.findOne({
            where :{ id : req.params.id }
        })
        
        fs.unlinkSync(data.path);

        await data.destroy();

        return res.status(200).json({
            data: [],
            status: true,
            message: "Advertisment banner deleted successfully"
        });
         
        
         
    }catch(err){
         err.status=400;
         next(err);
    }
    
}

exports.all_adv_banner = async(req,res,next)=>{
 
    try{
        
        const data = await advertisment.findAll()

        return res.status(200).json({
            data: data,
            status: true,
            message: "Advertisment banners list"
        });
         
    }catch(err){
         err.status=400;
         next(err);
    }
    
}
