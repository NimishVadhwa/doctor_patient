const joi = require('joi');
const user = require('../models/UserModel');
const schedule = require('../models/SchdeuleModel');
const calender = require('../models/Calender_dateModel');
const booking = require('../models/BookingModel');
const user_profile = require('../models/User_profileModel');
const re_schedule = require('../models/Re_scheduleModel');
const question = require('../models/QuestionsModel');
const answer = require('../models/AnswerModel');
const user_anwser = require('../models/UserAnswerModel');
const re_schedule_patient = require('../models/Re_schedule_patientModel');
const { Op } = require("sequelize");
const category = require('../models/CategoryModel');
const { send_notification, get_user,get_admin } = require('../helper');

//booking
exports.time_list = async (req, res, next) => {

    const schema = joi.object({
        date: joi.string().required()
    })

    try {
        
        await schema.validateAsync(req.body);

        const data = await calender.findAll({
            where : { date : req.body.date },
            include:[{
                model : schedule,
            }],
            group: ['schedules.start_time', 'schedules.end_time']
        });
       
        return res.status(200).json({
            data: data,
            status: true,
            message: "Time slot list by date"
        });

    } catch (err) {
        err.status = 400;
        next(err);
    }

}

exports.all_booking = async(req,res,next)=>{
    
    try{
        
        const data = await booking.findAll({
            where :{ user_id : req.user_id },
            include:[{
                model : user,
                as: "doctor",
                include :[{
                    model : user_profile
                }]
            },
            {
                model : user,
                as: "patient"
            },
            {
                model : schedule
            },
            {
                model : calender
            },{
                model : re_schedule_patient
            }]
        });
        
        return res.status(200).json({
            data: data,
            status: true,
            message: "All appoitment of patient"
        });
        
    }
    catch(err){
        err.status = 400;
        next(err);
    }
    
}

exports.booking_by_date = async(req,res,next)=>{
    
     const schema = joi.object({
        patient_id: joi.number().required(),
        date: joi.string().required(),
    });

    try {
        await schema.validateAsync(req.body);

        let dta = new Date(req.body.date);

        let row = await calender.findOne({ where: { date: dta.toISOString().split('T')[0] } });

        const data = await booking.findAll({
            where :{ user_id : req.body.patient_id, calender_id : row.id },
            include:[{
                model : user,
                as: "doctor",
                include :[{
                    model : user_profile
                }]
            },
            {
                model : user,
                as: "patient"
            },
            {
                model : schedule
            },
            {
                model : calender
            }]
        });


        return res.status(200).json({
            data: data,
            status: true,
            message: "appoitment list by date successfully"
        });

    } catch (err) {
        err.status = 400;
        next(err);
    }
    
}

exports.booking = async (req, res, next) => {

    const schema = joi.object({
        date : joi.string().required(),
        start_time : joi.string().required(),
        end_time : joi.string().required()
    });

    try {

        await schema.validateAsync(req.body);

        let dta = new Date(req.body.date);
        
        const [row, created] = await calender.findOrCreate({
            where: { date: dta.toISOString().split('T')[0] },
            defaults: {
                date: dta.toISOString().split('T')[0],
                year: dta.getFullYear(),
                month: dta.getMonth() + 1
            }
        });
        
        let check = await booking.findOne({
            where:{ 
                user_id : req.user_id,
                status: {[Op.ne]: 'completed'},
                [Op.and]: [
                            { status: {[Op.ne]: 'cancel'} },
                            { status: {[Op.ne]: 'reject'} }
                    ]
                
            }
        });
        
        
        if(check)
        { 
            throw new Error('You already have an apppointment you cannot book an appointment until the completion of other Appointments');
        }

        let bd = await booking.create({
            start_time : req.body.start_time,
            end_time : req.body.end_time,
            status : 'pending',
            calender_id :row.id,
            user_id : req.user_id
        });
        
        //patient notification
        let user_d = await get_user(req.user_id);
        let msg_p = 'Your booking has successfully requested on date '+ req.body.date + ' with booking id: '+ bd.id
        await send_notification(user_d.fcm_token,'booking request successfully',msg_p,user_d.id,'booking_request',bd.id,user_d.type)  
        
        
        // admin notification
        let admin_d = await get_admin();
        let msg = user_d.first_name+' '+user_d.last_name +' has new appointment on date '+ req.body.date + ' with booking id: '+ bd.id;
        await send_notification(admin_d.fcm_token,'New booking',msg,admin_d.id,'booking_request',bd.id,'admin')   
        
        
        return res.status(200).json({
            data: [],
            status: true,
            message: "Slot book successfully"
        });

    } catch (err) {
        err.status= 400;
        next(err);
    }

}

exports.cancel_booking = async(req, res, next)=>{
    
    const schema = joi.object({
        reason : joi.string().required(),
        booking_id : joi.number().required()
    });

    try {
        await schema.validateAsync(req.body);

        const data = await booking.findOne({
            where : { id:req.body.booking_id },
            include:[{
                model : calender
            }]
        });
        
        await schedule.update({
            status : "0"
        },{
            where :{ id : data.sch_id }
        })
        
        data.status = 'cancel';
        data.reason = req.body.reason;
        await data.save();
        
        
        //doctor notification if assigned
        if(data.doctor_id)
        {
            let user_d = await get_user(data.doctor_id);
            let msg_p = 'Booking has cancel on date '+ data.calender_date.date + ' with booking id: '+ data.id
            await send_notification(user_d.fcm_token,'Booking cancel',msg_p,user_d.id,'booking_cancel',data.id,user_d.type)  
            
        }
        
        //patient notification
        let user_d = await get_user(data.user_id);
        let msg_p = 'Your booking has cancel on date '+ data.calender_date.date + ' with booking id: '+ data.id
        await send_notification(user_d.fcm_token,'Booking cancel',msg_p,user_d.id,'booking_cancel',data.id,user_d.type)  
        
        
        // admin notification
        let admin_d = await get_admin();
        let msg = user_d.first_name+' '+user_d.last_name +' has cancel booking on date '+ data.calender_date.date + ' with booking id: '+ data.id;
        await send_notification(admin_d.fcm_token,'Booking cancel',msg,admin_d.id,'booking_cancel',data.id,'admin')   
        
        

        return res.status(200).json({
            data: [],
            status: true,
            message: "Re-schedule Successfull"
        });

    } catch (err) {
        err.status= 400;
        next(err);
    }

}

exports.request_list = async (req, res, next) => {

    try {

        const data = await booking.findAll({
            where :{ status :'pending' },
            include:[{
                model:user,
                as:"patient"
            },{
                model : calender
            }]
        });
        
        return res.status(200).json({
            data: data,
            status: true,
            message: "Request list"
        });

    } catch (err) {
        err.status = 400;
        next(err);
    }

}

exports.assign_doctor = async (req, res, next) => {

    const schema = joi.object({
        doctor_id : joi.number().allow(null),
        status : joi.string().required(),
        slot_id : joi.number().allow(null),
        booking_id : joi.number().required(),
        reason:joi.string().allow(null)
    });

    try {
        await schema.validateAsync(req.body);
        
        let bd = await booking.findOne({
            where : { id : req.body.booking_id },
            include:[{
                model:calender
            }]
        });

        if(req.body.reason)
        {
            bd.status = req.body.status;
            bd.reason = req.body.reason;
            await bd.save();
            
            //patient notification
            let user_d = await get_user(bd.user_id);
            let msg_p = 'Admin cancel your booking requested on date '+ bd.calender_date.date + ' with booking id: '+ bd.id + '. The reason for cancel the booking is : '+req.body.reason
            await send_notification(user_d.fcm_token,'booking cancel',msg_p,user_d.id,'cancel_booking_request',bd.id,user_d.type)  
            
            
            return res.status(200).json({
                data: [],
                status: true,
                message: "Reject Successfull"
            });
        }

        const check = await schedule.findOne({
            where :{ id: req.body.slot_id },
            include:[{
                model : booking
            }]
        })

        if(!check) throw new Error('Schedule/ slot not found');
        
        if(req.body.slot_id)
        {
            await schedule.update({
                status : "1"
            },{
                where : { id: req.body.slot_id }
            })
        }

        bd.sch_id= req.body.slot_id;
        bd.doctor_id= req.body.doctor_id;
        bd.status = req.body.status;
        // bd.reason = req.body.reason;
        await bd.save();
    
        //patient notification
        let user_d = await get_user(bd.user_id);
        let msg_pp = 'Admin approved your booking on date '+ bd.calender_date.date + ' with booking id: '+ bd.id;
        await send_notification(user_d.fcm_token,'Booking approved',msg_pp,user_d.id,'booking_approved',bd.id,user_d.type)  
        
        
        //doctor notification
        let user_dd = await get_user(req.body.doctor_id);
        let msg_p = 'Admin assign you a booking on date '+ bd.calender_date.date + ' with booking id: '+ bd.id;
        await send_notification(user_dd.fcm_token,'Assign booking',msg_p,user_dd.id,'booking_approved',bd.id,user_dd.type)  
        

        return res.status(200).json({
            data: [],
            status: true,
            message: "Successfull"
        });

    } catch (err) {
        err.status = 400;
        next(err);
    }

}

exports.patient_feedback = async(req,res,next)=>{
    
    const schema = joi.object({
        booking_id : joi.number().required(),
        feedback : joi.string().required(),
        rating : joi.number().required(),
        doctor_id : joi.number().required()
    });
    
    try{
        await schema.validateAsync(req.body);
        
        let bd = await booking.findOne({
            where : { id : req.body.booking_id },
            include:[{
                model:calender
            }]
        });
        
        bd.rating = req.body.rating;
        bd.feedback = req.body.feedback;
        await bd.save();
       
        const data = await booking.findAll({
            where : { doctor_id : req.body.doctor_id }
        });
        
        let i = 0;
        let r = 0;
        data.forEach( async(element)=>{
            
            if(element.rating){
                i += 1;
                r += element.rating
            }   
            
        })
        
        let avg = r/i;
        
        await user.update({ rating : avg },{
            where : {id : req.body.doctor_id }
        });
        
        //doctor notification
        let user_d = await get_user(req.body.doctor_id);
        let msg_p = 'Patient give you a rating on booking on date '+ bd.calender_date.date
        await send_notification(user_d.fcm_token,'Patient rating',msg_p,user_d.id,'rating',bd.id,user_d.type)  
        
        
        // admin notification
        let admin_d = await get_admin();
        let msg = 'patient give rating to doctor on booking on date '+ bd.calender_date.date + ' of booking id: '+ bd.id;
        await send_notification(admin_d.fcm_token,'Patient rating',msg,admin_d.id,'rating',bd.id,'admin')   
        

        
        return res.status(200).json({
            data: [],
            status: true,
            message: "feedback given Successfull"
        });
        
    }catch(err){
        err.status = 400;
        next(err);
    }
    
}

//Re-schdule
exports.re_schedule_list_by_patient = async (req, res, next) => {

    try {
        
        const data = await booking.findAll({
            where: { status : "re_schedule_pending", is_doctor_apply :'0' },
             include:[{
                    model :calender
                },{
                    model :user,
                    as:"patient"
                },
                {
                    model : re_schedule_patient,
                    where : { status : "pending" },
                    include:[{
                        model : calender
                    }]
                }]
        })

        return res.status(200).json({
            data: data,
            status: true,
            message: "Re-schdule apply list of patient"
        });

    } catch (err) {
        err.status = 400;
        next(err);
    }

}

exports.apply_re_schedule_patient = async (req, res, next) => {

    const schema = joi.object({
        date : joi.string().required(),
        start_time : joi.string().required(),
        end_time : joi.string().required(),
        booking_id : joi.number().required()
    });

    try {

        await schema.validateAsync(req.body);

        let dta = new Date(req.body.date);
        
        const [row, created] = await calender.findOrCreate({
            where: { date: dta.toISOString().split('T')[0] },
            defaults: {
                date: dta.toISOString().split('T')[0],
                year: dta.getFullYear(),
                month: dta.getMonth() + 1
            }
        });

        const check = await booking.findOne({
            where :{ id: req.body.booking_id },
            include:[{
                model:calender
            }]
        });
        
        if(!check) throw new Error('Booking not found');
        
        await re_schedule_patient.create({
            start_time : req.body.start_time,
            end_time : req.body.end_time,
            status : 'pending',
            calender_id : row.id,
            user_id : req.user_id,
            booking_id : req.body.booking_id,
            doctor_id : check.doctor_id,
            schedule_id : check.sch_id
        });

        await booking.update({ status : "re_schedule_pending", is_doctor_apply:'0' },{
            where : { id: req.body.booking_id }
        })
        
        
        // admin notification
        let admin_d = await get_admin();
        let msg = 'Patient apply for re-schedule on booking date '+ check.calender_date.date + ' of booking id: '+ check.id;
        await send_notification(admin_d.fcm_token,'Patient apply for re-schedule',msg,admin_d.id,'apply_re_schedule',check.id,'admin')   
        

        
        return res.status(200).json({
            data: [],
            status: true,
            message: "Re-schedule apply successfully"
        });

    } catch (err) {
        err.status= 400;
        next(err);
    }

}

exports.confirm_reschedule_apply_by_patient = async(req, res, next)=>{

    const schema = joi.object({
        booking_id : joi.number().required(),
        rs_schdule_id : joi.number().required(),
        doctor_id : joi.number().required(),
        sch_id : joi.number().required(),
    });

    try {

        await schema.validateAsync(req.body);

        const check = await booking.findOne({
            where : { id : req.body.booking_id },
            include:[{
                model:calender
            }]
        });
        
        if(!check) throw new Error('Booking is not found');
        
        //doctor notification
        let user_dd = await get_user(check.doctor_id);
        let msg = 'Admin cancel your booking on date '+ check.calender_date.date+' beacuse patient apply for re-schedule'
        await send_notification(user_dd.fcm_token,'Booking re-schedule by patient',msg,user_dd.id,'doctor_cancel_booking',0,user_dd.type)  
        
        
        let st = check.start_time;
        let et = check.end_time;
        let cal = check.calender_id;
        
        const re_data = await re_schedule_patient.findOne({
            where :{ id : req.body.rs_schdule_id }
        });
        
        check.start_time = re_data.start_time;
        check.end_time = re_data.end_time;
        check.calender_id = re_data.calender_id;
        check.sch_id  = req.body.sch_id ;
        check.doctor_id  = req.body.doctor_id ;
        check.status = "accepted";
        await check.save();
        
        re_data.start_time = st;
        re_data.end_time = et;
        re_data.calender_id = cal;
        re_data.status = "accept"
        await re_data.save();
        
        
        //patient notification
        let user_d = await get_user(check.user_id);
        let msg_p = 'Admin has confirmed your re-schedule on booking date '+ check.calender_date.date
        await send_notification(user_d.fcm_token,'Confirm re-schedule',msg_p,user_d.id,'confirm_re_schedule',0,user_d.type)  
        
       
        return res.status(200).json({
            data: [],
            status: true,
            message: "Re-schedule accept Successfully of patient"
        });

    } catch (err) {
        console.log(err);
        err.status =400;
        next(err);
    }

}

exports.cancel_re_schedule_patient = async(req,res,next)=>{
    
    const schema = joi.object({
        re_schedule_id : joi.number().required(),
        booking_id : joi.number().required(),
        reason: joi.string().required()
    });
    
    try{
        await schema.validateAsync(req.body);
       
        const dt = await re_schedule_patient.update({
            reason : req.body.reason,
            status :"cancel"
        },{
            where :{ id : req.body.re_schedule_id }
        });
       
        let check = await booking.findOne({
            where:{ id : req.body.booking_id },
            include:[{
                model:calender
            }]
        });
       
        check.status = "accepted";
        await check.save();
       
        // await booking.update({
        //     status : "accepted"
        // },{
        //     where : { id : req.body.booking_id }
        // });
        
       
        //patient notification
        let user_d = await get_user(check.user_id);
        let msg_p = 'Admin has cancel your re-schedule on booking date '+ check.calender_date.date
        await send_notification(user_d.fcm_token,'Cancel re-schedule',msg_p,user_d.id,'cancel_re_schedule',0,user_d.type)  
       
       
        return res.status(200).json({
            data: [],
            status: true,
            message: "Re-schedule cancel Successfully of patient"
        });
        
    }catch(err){
        err.status = 400;
        next(err);
    }
    
}

// questions
exports.all_questions = async(req,res,next)=>{
    
    const schema = joi.object({
       gender : joi.string().required().valid('male','female')
    });
    
    try{
        
        await schema.validateAsync(req.params);
        
        // const data = await category.findAll({
        //     include:[{
        //         model:question,
        //         where:{ gender : req.params.gender },
        //          include:[{
        //             model : answer
        //         }]
        //     }]
        // })
        
        const data = await question.findAll({
            where:{ gender : req.params.gender,question_id :null },
            order:[['id','ASC']],
            include:[{
                model:question,
                as:'sub_question',
                include:[{
                    model:answer,
                    attributes: {exclude: ['createdAt','updatedAt']}    
                }]
            },{
                model : answer,
                required:false,
                attributes: {exclude: ['createdAt','updatedAt']}
            },{
                model:category
            }]
        });
        
        return res.status(200).json({
            data: data,
            status: true,
            message: "Questions with all options"
        });
        
    }
    catch(err){
        err.status = 500;
        next(err);
    }
    
}

exports.add_user_answer = async(req,res,next)=>{
    
    const schema = joi.object({
        column: joi.array().required()
    })

    try {
        
        await schema.validateAsync(req.body);

        req.body.column.forEach( async(element)=>{
            await user_anwser.create({ 
                user_id : req.user_id,
                answer_data : element.answer_data,
                question_id : element.question_id,
                answer_id : element.answer_id,
                check_data:'true'
            });
            
        });

        

        return res.status(200).json({
            data: [],
            status: true,
            message: "Answer add successfully"
        });

    } catch (err) {
        err.status = 400;
        next(err);
    }

    
}

exports.get_answer = async(req,res,next)=>{

    try {

        const data = await user_anwser.findAll({
            where : { user_id  : req.user_id },
            include:[{
                model : question
            }]
        })
        
        // const user = await get_user(req.user_id);
        
        // const ques = await question.findAll({
        //     where:{ gender : user.user_profile.gender,question_id :null },
        //     attributes:['id']
        // });
        
        
        // let arr= [];
        
        // ques.forEach(element=>{
            
        //     if(arr.indexOf(element.id) == -1)
        //     {
        //         arr.push( element.id )
        //     }
            
        // });
        
        //   let arr= [];
        
        // data.forEach(element=>{
            
        //     if(arr.indexOf(element.doctor_id) == -1)
        //     {
        //         arr.push( element.doctor_id )
        //     }
            
        // });
        
        
        // let where = {
        //   id : arr
        // }
        
        
        // data.forEach(async(element)=>{
            
        // })

        return res.status(200).json({
            data: data,
            completed:true,
            status: true,
            message: "All answers of the patient"
        });

    } catch (err) {
        err.status = 400;
        next(err);
    }

    
}

exports.get_answer_by_id = async(req,res,next)=>{

    try {

        const data = await user_anwser.findAll({
            where : { user_id  : req.params.id },
            include:[{
                model : question
            }]
        })

        return res.status(200).json({
            data: data,
            status: true,
            message: "All answers of the patient"
        });

    } catch (err) {
        err.status = 400;
        next(err);
    }

    
}

exports.delete_answers = async(req,res,next)=>{
    
     const schema = joi.object({
        id: joi.string().required()
    })

    try {
        
        await schema.validateAsync(req.params);

        
        // const data = await user_anwser.findAll({
        //     where:{ user_id : req.params.id }
        // });
    
        await user_anwser.destroy({
             where:{ user_id : req.params.id }
        });    

        return res.status(200).json({
            data: [],
            status: true,
            message: "User Answer deleted successfully"
        });

    } catch (err) {
        err.status = 400;
        next(err);
    }

}

exports.doctor_list = async(req,res,next)=>{
    
    try{
        
        const data = await booking.findAll({
            where : { 
                user_id : req.user_id, 
                doctor_id: {
                    [Op.ne]: null 
                }
            }
        });
        
        let arr= [];
        
        data.forEach(element=>{
            
            if(arr.indexOf(element.doctor_id) == -1)
            {
                arr.push( element.doctor_id )
            }
            
        });
        
        
        let where = {
           id : arr
        }
        
        if(req.body.word) {  
            // console.log('asdf');
            where = { 
                id : arr, 
                [Op.or]: [
                        { first_name: {[Op.substring]: req.body.word} },
                        { last_name: {[Op.substring]: req.body.word} }
                    ],  
                
            } 
            
        }
       
        
        const dta = await user.findAll({
            where,
            include:[{
                model :user_profile
            },{
                model : booking,
                as : "doctor",
                include: [{
                    model : calender,
                    attributes : ['date']
                }]
            }]
        })
        
         return res.status(200).json({
            data: dta,
            status: true,
            message: "All doctor list of the patient"
        });
        
    }catch(err){
        console.log(err);
        err.status = 400;
        next(err);
    }
    
}
