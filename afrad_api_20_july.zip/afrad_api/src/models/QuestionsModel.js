const { Model, DataTypes } = require('sequelize');
const database = require('../database');
const category = require('./CategoryModel.js');

class question extends Model { }

question.init(
    {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            allowNull: false,
            primaryKey: true
        },
        question: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        type: {
            type: DataTypes.ENUM('select','radio','text','date'),
            allowNull: true
        },
        gender: {
            type: DataTypes.ENUM('male','female'),
            allowNull: false,
            defaultValue: 'male',
        }
    },
    {
        sequelize: database,
        modelName: "question",
        underscored: true

    }

);


category.hasMany(question, { onDelete: "CASCADE", foreignKey: "category_id" });
question.belongsTo(category,{ foreignKey: "category_id" });

question.hasMany(question, { onDelete: "CASCADE",as:"sub_question", foreignKey: "question_id" });
question.belongsTo(question,{ foreignKey: "question_id",as:"parent_question" });


module.exports = question;