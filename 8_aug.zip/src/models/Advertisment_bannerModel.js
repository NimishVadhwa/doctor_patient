const { Model, DataTypes } = require('sequelize');
const database = require('../database');

class advertisment_banner extends Model { }

advertisment_banner.init(
    {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            allowNull: false,
            primaryKey: true
        },
        title: {
            type: DataTypes.TEXT,
            allowNull: false
        },
        desc: {
            type: DataTypes.TEXT,
            allowNull: false
        },
        path: {
            type: DataTypes.TEXT,
            allowNull: false
        }
        
    },
    {
        sequelize: database,
        modelName: "advertisment_banner",
        underscored: true

    }

);


module.exports = advertisment_banner;