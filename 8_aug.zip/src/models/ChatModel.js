const { Model, DataTypes } = require('sequelize');
const database = require('../database');
const user = require('./UserModel');
const room = require('./RoomModel');

class chat extends Model { }

chat.init(
    {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            allowNull: false,
            primaryKey: true
        },
        message: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        room_name: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        file_type: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        status: {
            type: DataTypes.ENUM('unread', 'read'),
            allowNull: false,
            defaultValue: 'unread'
        },
        del_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            defaultValue: 0
        },
    },
    {
        sequelize: database,
        modelName: "chat",
        underscored: true

    }

);

room.hasMany(chat, { onDelete: "CASCADE", foreignKey: "room_id" });
chat.belongsTo(room, { foreignKey: "room_id" });

user.hasMany(chat, { onDelete: "CASCADE", foreignKey: "sender_id" });
chat.belongsTo(user, { foreignKey: "sender_id" });

user.hasMany(chat, { onDelete: "CASCADE", foreignKey: "receiver_id" });
chat.belongsTo(user, { foreignKey: "receiver_id" });


module.exports = chat;