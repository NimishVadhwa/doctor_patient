const { Model, DataTypes } = require('sequelize');
const database = require('../database');
const user = require('./UserModel');

class room extends Model { }

room.init(
    {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            allowNull: false,
            primaryKey: true
        },
        room_name: {
            type: DataTypes.TEXT,
            allowNull: true
        }
    },
    {
        sequelize: database,
        modelName: "room",
        underscored: true

    }

);

user.hasMany(room, { onDelete: "CASCADE", foreignKey: "user_id", as:"patients" });
room.belongsTo(user, { foreignKey: "user_id", as:"patients" });

user.hasMany(room, { onDelete: "CASCADE", foreignKey: "doctor_id", as:"doctors" });
room.belongsTo(user, { foreignKey: "doctor_id", as:"doctors" });

user.hasMany(room, { onDelete: "CASCADE", foreignKey: "admin_id", as:"admins" });
room.belongsTo(user, { foreignKey: "admin_id", as:"admins" });


module.exports = room;