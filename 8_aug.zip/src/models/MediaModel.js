const { Model, DataTypes } = require('sequelize');
const database = require('../database');
const booking = require('./BookingModel.js');
const user = require('./UserModel');


class media extends Model { }

media.init(
    {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            allowNull: false,
            primaryKey: true
        },
        name: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        path: {
            type: DataTypes.TEXT,
            allowNull: false
        },
        type: {
            type: DataTypes.ENUM('banner','report'),
            allowNull: false,
            defaultValue: 'banner',
        }
        
    },
    {
        sequelize: database,
        modelName: "media",
        underscored: true

    }

);

booking.hasMany(media, { onDelete: "CASCADE", foreignKey: "booking_id", as:"report" });
media.belongsTo(booking,{ foreignKey: "booking_id", as:"report" });

user.hasMany(media, { onDelete: "CASCADE", foreignKey: "user_id" });
media.belongsTo(user, { foreignKey: "user_id" });

module.exports = media;