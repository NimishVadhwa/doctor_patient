const { Model, DataTypes } = require('sequelize');
const database = require('../database');

class category extends Model { }

category.init(
    {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            allowNull: false,
            primaryKey: true
        },
        category_name: {
            type: DataTypes.TEXT,
            allowNull: false
        }
        
    },
    {
        sequelize: database,
        modelName: "category",
        underscored: true

    }

);


module.exports = category;